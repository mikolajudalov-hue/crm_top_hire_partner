# Shared constants for pipeline etc.
PIPELINE = ["Подан","Вышел на работу","Не вышел","Отработал месяц","Не отработал"]
